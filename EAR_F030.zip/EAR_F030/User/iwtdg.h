#ifndef __IWTDG_H
#define __IWTDG_H
void Init_iWtdg(unsigned char prer,unsigned short rlr);

void IWDG_Feed(void);
#endif  // __WTDG_H
