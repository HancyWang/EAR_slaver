#ifndef __DEVICE_TYPE_H
#define __DEVICE_TYPE_H
//#define STM32F030F4P6
#define STM32F070
//#define STM32F030C8T6
#endif
